package com.Techno23.CoinQuest;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.Techno23.CoinQuest.Dao.AppDao;
import com.Techno23.CoinQuest.Entity.Achievement;
import com.Techno23.CoinQuest.Entity.Card;
import com.Techno23.CoinQuest.Entity.Team;

@SpringBootApplication
public class CoinQuestApplication {

	Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		SpringApplication.run(CoinQuestApplication.class, args);
	}

	@Bean
	public CommandLineRunner commandLineRunner(AppDao appDao){
		return runner ->{
			System.out.println("Enter the round number. (Enter 7 to obtain the results.)");
			int round = sc.nextInt();
			while(round!=-1){
				switch(round){
					case 0:
						printMenuForRound0();
						int choice = sc.nextInt();
						sc.nextLine();
						clearScreen();
						while(choice!=-1){
							switch(choice){
								case 1:
									createTeam(appDao);
									break;
								// case 2:
								// 	createCard(appDao);
								// 	break;
								// case 3:
								// 	createCondition(appDao);
								// 	break;
								default:
								System.out.println("wrong choice");
								break;	
							}
							printMenuForRound0();
							choice = sc.nextInt();
							sc.nextLine();
							clearScreen();
						}
						break;
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
						printMenu();
						int ch = sc.nextInt();
						while(ch!=-1){
							clearScreen();
							switch (ch) {
								case 1:
									buyCard(appDao);
									break;
								case 2:
									addAPoints(appDao);
									break;
								case 3:
									removeAPoints(appDao);
									break;
								case 4:
									addMoney(appDao);
									break;
								case 5:
									removeMoney(appDao);
									break;
								case 6:
									transferMoney(appDao);
									break;
								case 7:
									removeCard(appDao);
									break;
								case 8:
									transferCard(appDao);
									break;
								case 9:
									getCardList(appDao);
									break;
								default:
									System.out.println("wrong choice");
							}
							printMenu();
							ch = sc.nextInt();
							if(ch == -1){
								findTeamWithMaxPurse(appDao);
							}
						}
						break;
					case 7:
						calculateRank(appDao);
						break;
					default:
						System.out.println("wrong choice!!");
				}
				System.out.println("Enter the round number. (Enter 7 to obtain the results.)");
				round = sc.nextInt();
			}
		};
	}

	public static void clearScreen() {  
		System.out.print("\033[H\033[2J");  
		System.out.flush();  
	}

	public void printMenuForRound0(){
		System.out.println();
		System.out.println("   Menu   ");
		System.out.println("----------");
		System.out.println("1. Register a team in the DataBase.");
		// System.out.println("2. Register a card in the DataBAse.");
		// System.out.println("3. Add Aurum condition.");
		System.out.println();
		System.out.print("Enter your choice - ");
	}

	public void printMenu(){
		System.out.println();
		System.out.println("  Menu  ");
		System.out.println("---------");
		System.out.println("1. Buy a card for a Team.");
		System.out.println("2. Add Aurums to a Team");
		System.out.println("3. Use Aurums for a Team");
		System.out.println("4. Add Embers to a Team.");
		System.out.println("5. Remove Embers from a Team.");
		System.out.println("6. Transfer Embers from one Team to another Team.");
		System.out.println("7. Remove a Card from a Team.");
		System.out.println("8. Transfer a card from one Team to Another");
		System.out.println("9. See the Cards of a team.");
		System.out.println();
		System.out.print("Enter your choice - ");
	}

	public void createTeam(AppDao appDao){
		System.out.println("Enter the Name of first participant.");
		String name1 = sc.nextLine();
		System.out.println("Enter the Roll Number of First Participant.");
		String roll1 = sc.nextLine();
		System.out.println("Enter the Name of second participant.");
		String name2 = sc.nextLine();
		System.out.println("Enter the Roll Number of Second Participant.");
		String roll2 = sc.nextLine();
		System.out.println("Enter the Team Name.");
		String teamName = sc.nextLine();
		appDao.createNewTeam(name1, roll1, name2, roll2, teamName);
	}

	public void createCard(AppDao appDao){
		System.out.println("Enter the Stardust (points) of the card.");
		int points = sc.nextInt();
		System.out.println("Enter the Category of the Card");
		int category = sc.nextInt();
		System.out.println("Enter the Base Price of the Card");
		int basePrice = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the Name of the Card");
		String name = sc.nextLine();
		Card tempCard = new Card(points,category,name,basePrice);
		appDao.addCardinDB(tempCard);
		System.out.println("New Card named "+name.toUpperCase()+" created successfully with ID "+tempCard.getId());
	}

	private void createCondition(AppDao appDao) {
		System.out.println("Enter the Name of the Aurum Condition.");
		String name = sc.nextLine();
		System.out.println("Enter the Description of this Aurum Condition.");
		String description = sc.nextLine();
		System.out.println("Enter the number of Aurums that is awarded on completing this Condition.");
		int n = sc.nextInt();
        Achievement achievement = new Achievement(name, description, n);
		appDao.addConditioninDB(achievement);
        System.out.println("New Aurum condition added successfully with ID "+achievement.getId());
	}

	public void buyCard(AppDao appDao){
		System.out.println("Enter the Team ID to which you want to add a Card");
		int id = sc.nextInt();
		if(appDao.findTeam(id).getCards().size()==6){
			System.out.println("Maximum number of cards reached.");
			appDao.removeMoney(id, 2000);
			System.out.println("Penalty of 2000 Embers imposed.");
			return;
		}
		System.out.println("Enter the Card ID which you want to add to Team "+id+" - ");
		int cardId = sc.nextInt();
		System.out.println("Enter the Selling Price of the card with ID "+cardId+" - ");
		int sp = sc.nextInt();
		boolean check = appDao.buyCard(id,cardId,sp);
		if(!check){
			System.out.println("Card already bought or not enough Embers.");
		}
		List<Card> cardList = appDao.getCardList(id);
		Achievement one = appDao.findAchievement(1);
		Achievement three = appDao.findAchievement(3);
		Achievement two = appDao.findAchievement(2);
		Achievement eight = appDao.findAchievement(8);
		if(cardList.size() == 6 && eight.getClaimed()==0){
			System.out.println("The team can claim 60 Aurums using condition id 8 - FULL HOUSE - collecting all 6 Cards.");
			System.out.println("Do the team wants to claim? Enter 1 if they claim else 0.");
			int choice = sc.nextInt();
			if(choice == 1){
				eight.setClaimed(1);
				appDao.findTeam(id).addAchivement(eight);
				appDao.addAchievementPoints(id, eight.getPoints());
				appDao.updateAchievement(eight);
			}
		}
		if(cardList.size() >= 4){
			int arr[] = new int[5];
			for(int i = 0 ; i<cardList.size(); i++){
				arr[cardList.get(i).getCategory()]++;
			}
			int count = 0;
			for(int i = 1; i<5; i++){
				if(arr[i]>0){
					count++;
				}
			}
			if(count >= 3 && one.getClaimed()==0){
				System.out.println("The team can claim 40 Aurums using condition id 1 - TrioSaga - 3 different categories among 4 or more cards.");
				System.out.println("Do the team wants to claim? Enter 1 if they claim else 0");
				int choice = sc.nextInt();
				if(choice == 1){
					one.setClaimed(1);
					appDao.findTeam(id).addAchivement(one);
					appDao.addAchievementPoints(id, one.getPoints());
					appDao.updateAchievement(one);
				}
			}
			if(count >= 4 && three.getClaimed()==0){
				System.out.println("The team can claim 60 Aurums using condition id 3 - Quadrella - 4 different categories among 4 or more cards.");
				System.out.println("Do the team wants to claim? Enter 1 if they claim else 0");
				int choice = sc.nextInt();
				if(choice == 1){
					three.setClaimed(1);
					appDao.findTeam(id).addAchivement(three);
					appDao.addAchievementPoints(id, three.getPoints());
					appDao.updateAchievement(three);
				}
			}
		}
		if(cardList.size()>=3){
			int count = 0;
			for(int i=0;i<cardList.size();i++){
				if(cardList.get(i).getCategory()==1){
					count++;
				}
			}
			if(count>0 && two.getClaimed()==0){
				System.out.println("The team can claim 35 Aurums using condition id 2 - SoulForge - containg atleast 1 CELESTIAL LEGEND.");
				System.out.println("Do the team wants to claim? Enter 1 if they claim else 0.");
				int choice = sc.nextInt();
				if(choice == 1){
					two.setClaimed(1);
					appDao.findTeam(id).addAchivement(two);
					appDao.addAchievementPoints(id, two.getPoints());
					appDao.updateAchievement(two);
				}
			}
		}
	}

	public void addAPoints(AppDao appDao){
		System.out.println("Enter Team ID to which you want to add Aurums.");
		int id = sc.nextInt();
		System.out.println("Enter the amount of Aurums you want to add - ");
		int points = sc.nextInt();
		appDao.addAchievementPoints(id, points);
	}

	private void removeAPoints(AppDao appDao) {
		clearScreen();
		System.out.println("Enter team id who want to use their Aurums");
		int id = sc.nextInt();
		System.out.println("Which SKILL does the Team want to use? ");
		System.out.println();
		System.out.println("1. Steal - 60 Aurums");
		System.out.println("2. Freeze - 30 Aurums");
		System.out.println("3. Discount - 25 Aurums");
		System.out.println("4. Upgrade  - 50 Aurums");
		System.out.println("5. Bank - 40 Aurums");
		System.out.println("6. Blaze - 35 Aurums");
		System.out.println("7. Bankrupt - 25 Aurums");
		System.out.println();
		System.out.println("Enter 0 for doing nothing and go back to previous menu.");
		System.out.println();
		System.out.println("Enter your choice - ");
		int choice = sc.nextInt();
		if(choice == 0){
			System.out.println("Returning to previous menu.");
			return;
		}else if(choice>7 && choice<0){
			System.out.println("Wrong choice!! Returning to previous menu.");
			return;
		}else{
			clearScreen();
			appDao.removeAurums(id, choice);
		}
	}

	public void addMoney(AppDao appDao){
		System.out.println("Enter Team ID to which you want to add Embers");
		int id = sc.nextInt();
		System.out.println("Enter the amount of Embers to be added - ");
		int amount = sc.nextInt();
		appDao.addMoney(id, amount);
	}

	public void removeMoney(AppDao appDao){
		System.out.println("Enter Team ID from which you want to remove Embers");
		int id = sc.nextInt();
		System.out.println("Enter the amount of Embers to remove - ");
		int amount = sc.nextInt();
		appDao.removeMoney(id, amount);
	}

	public void transferMoney(AppDao appDao){
		System.out.println("Enter Team ID from which you want to transfer Embers.");
		int id = sc.nextInt();
		System.out.println("Enter team Id to which you want to transfer Embers.");
		int id2 = sc.nextInt();
		System.out.println("Enter the amount of Embers to be transferred - ");
		int amount = sc.nextInt();
		appDao.tranferMoney(id, id2, amount);
	}

	public void removeCard(AppDao appDao){
		System.out.println("Enter the Team ID from which you want to remove a card - ");
		int id = sc.nextInt();
		System.out.println("Enter the Card ID which you want to remove - ");
		int cardId = sc.nextInt();
		appDao.removeCard(id, cardId);
	}

	public void transferCard(AppDao appDao){
		System.out.println("Enter Team ID from which you want to transfer the card - ");
		int id = sc.nextInt();
		System.out.println("Enter Team ID to which you want to transfer the card - ");
		int id2 = sc.nextInt();
		System.out.println("Enter the Card ID which is to be transferred - ");
		int cardId = sc.nextInt();
		appDao.tranferCard(id, id2, cardId);
	}

	private void findTeamWithMaxPurse(AppDao appDao) {
		List<Team> teams = appDao.getTeams();
		Team tempTeam = null;
		int max = Integer.MIN_VALUE;
		for(int i = 0; i<teams.size(); i++){
			if(teams.get(i).getAmount()>max && teams.get(i).getCards().size()>=1){
				tempTeam = teams.get(i);
				max = tempTeam.getAmount();
			}
		}
		System.out.println("The Team with max amount of Embers in purse is Team "+tempTeam.getId());
		appDao.addAchievementPoints(tempTeam.getId(), 25);
		System.out.println("Aurum condition with ID 5 - Gold Digger applied.");
	}

	private void calculateRank(AppDao appDao) {
		appDao.updateRanks();
	}

	public void getCardList(AppDao appDao){
		System.out.println("Enter the Team ID whose cards you want to see.");
		int teamId = sc.nextInt();
		List<Card> cards = appDao.getCardList(teamId);
		System.out.println("The cards for Team "+teamId+" are :");
		for(int i = 0; i<cards.size(); i++){
			System.out.println((i+1)+". "+cards.get(i).toString());
		}
	}
}
