package com.Techno23.CoinQuest.Entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "team")
public class Team {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    
    @Column(name = "name1")
    private String name1;

    @Column(name = "roll1")
    private String rollNumber1;

    @Column(name = "name2")
    private String name2;

    @Column(name = "roll2")
    private String rollNumber2;

    @Column(name = "team_name")
    private String teamName;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "team_id")
    private List<Card> cards;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "team_id")
    private List<Achievement> achievements;

    @Column(name = "amount")
    private int amount = 60000;

    @Column(name = "a_points")
    private int achievementPoints = 0;

    @Column(name = "team_rank")
    private int rank = 0;

    @Column(name = "c_points")
    private int commonPoints = 0;

    public int getCommonPoints() {
        return commonPoints;
    }

    public void setCommonPoints(int commonPoints) {
        this.commonPoints = commonPoints;
    }

    public Team() {
    }

    public Team(String name1, String rollNumber1, String name2, String rollNumber2, String teamName) {
        this.name1 = name1;
        this.rollNumber1 = rollNumber1;
        this.name2 = name2;
        this.rollNumber2 = rollNumber2;
        this.teamName = teamName;
    }

    public void addACard(Card tempCard){
        cards.add(tempCard);
    }
    public void addAchivement(Achievement tempAchievement){
        achievements.add(tempAchievement);
    }
    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return  "[rank=" + rank + ",Team id=" + id +", teamName=" + teamName + ", name1=" + name1 + ", rollNumber1=" + rollNumber1 + ", name2=" + name2
                + ", rollNumber2=" + rollNumber2 + ", commonPoints=" + commonPoints
                + "]";
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

    public String getRollNumber1() {
        return rollNumber1;
    }

    public void setRollNumber1(String rollNumber1) {
        this.rollNumber1 = rollNumber1;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }

    public String getRollNumber2() {
        return rollNumber2;
    }

    public void setRollNumber2(String rollNumber2) {
        this.rollNumber2 = rollNumber2;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public List<Card> getCards() {
        return cards;
    }

    public void setCards(List<Card> cards) {
        this.cards = cards;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getAchievementPoints() {
        return achievementPoints;
    }

    public void setAchievementPoints(int achievementPoints) {
        this.achievementPoints = achievementPoints;
    }
    
    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }
}
