package com.Techno23.CoinQuest.Dao;

import java.util.List;

import com.Techno23.CoinQuest.Entity.Achievement;
import com.Techno23.CoinQuest.Entity.Card;
import com.Techno23.CoinQuest.Entity.Team;

public interface AppDao {
    
    public void createNewTeam(String name1,String rollnum1,String name2,String rollNum2, String teamName);
    public void updateTeam(Team team);
    public Team findTeam(int teamId);
    public Card findCard(int cardId);
    public void addCardinDB(Card card);
    public void addConditioninDB(Achievement achievement);
    public void updateCard(Card theCard);
    public void updateAchievement(Achievement theAchievement);
    public Achievement findAchievement(int id);
    public void removeMoney(int teamId,int money);
    public void addMoney(int teamId, int money);
    public void tranferMoney(int fromId, int toid, int money);
    public void addAchievement(int teamId, int achievementId);
    public void addCard(int teamId, int cardId);
    public void removeCard(int teamId, int cardId);
    public void tranferCard(int teamId1, int teamId2, int cardId);
    public List<Team> getTeams();
    public void addAchievementPoints(int teamId, int points);
    public void removeAchievementPoints(int teamId, int points);
    public void removeAurums(int teamId, int points);
    public List<Card> getCardList(int teamId);
    public boolean buyCard(int teamId, int cardId,int sp);
    public void updateRanks();
}
