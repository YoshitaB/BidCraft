package com.Techno23.CoinQuest.Dao;
import java.util.List;
import java.util.Scanner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.Techno23.CoinQuest.Entity.Achievement;
import com.Techno23.CoinQuest.Entity.Card;
import com.Techno23.CoinQuest.Entity.Team;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

@Repository
public class appDaoImpl implements AppDao{

    Scanner sc = new Scanner(System.in);

    private EntityManager entityManager;
    
    @Autowired
    public appDaoImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public void createNewTeam(String name1, String rollnum1, String name2, String rollNum2, String teamName) {
        Team newTeam = new Team(name1, rollnum1, name2, rollNum2,teamName);
        entityManager.persist(newTeam);
        System.out.println("New team created successfully with id "+newTeam.getId()+" and amount in purse "+newTeam.getAmount());
    }

    @Override
    @Transactional
    public void updateTeam(Team team) {
        entityManager.merge(team);
    }

    @Override
    public Team findTeam(int teamId) {
        return entityManager.find(Team.class,teamId);
    }

    @Override
    @Transactional
    public void addCardinDB(Card card) {
        entityManager.persist(card);
    }

    @Override
    @Transactional
    public void updateCard(Card theCard) {
        entityManager.merge(theCard);
    }

    @Override
    public Card findCard(int cardId) {
        return entityManager.find(Card.class,cardId);
    }

    @Override
    @Transactional
    public void addConditioninDB(Achievement achievement) {
        entityManager.persist(achievement);
    }

    @Override
    @Transactional
    public void updateAchievement(Achievement theAchievement) {
        entityManager.merge(theAchievement);
    }

    @Override
    public Achievement findAchievement(int id){
        return entityManager.find(Achievement.class,id);
    }
    
    @Override
    @Transactional
    public void addCard(int teamId, int cardId) {
        Card tempCard = findCard(cardId);
        Team tempTeam = findTeam(teamId);
        tempTeam.addACard(tempCard);
        int currentCommonPoints = tempTeam.getCommonPoints();
        tempTeam.setCommonPoints(currentCommonPoints+tempCard.getPoints());
        updateTeam(tempTeam);
        System.out.println("Card Added successfully to team "+teamId+" and Amount remaining in purse with team "+ teamId+ " = "+tempTeam.getAmount());
    }

    @Override
    @Transactional
    public boolean buyCard(int teamId, int cardId, int sp) {
        Card tempCard = findCard(cardId);
        Team tempTeam = findTeam(teamId);
        int balance = tempTeam.getAmount();
        if(balance<sp){
            System.out.println("Not enough balance, cannot buy the card.");
            removeMoney(teamId, 2000);
            System.out.println("Penalty of 2000 Embers imposed on Team "+teamId);
            return false;
        }
        if(tempCard.getSellingPrice()!=0){
            return false;
        }
        tempTeam.addACard(tempCard);
        tempCard.setSellingPrice(sp);
        tempTeam.setAmount(balance-sp);
        int currentCommonPoints = tempTeam.getCommonPoints();
        tempTeam.setCommonPoints(currentCommonPoints+tempCard.getPoints());
        updateTeam(tempTeam);
        updateCard(tempCard);
        System.out.println("Card Added successfully to team "+teamId+". \nAmount remaining with team "+ teamId+ "= "+tempTeam.getAmount());
        return true;
    }

    @Override
    @Transactional
    public void removeCard(int teamId, int cardId) {
        Team tempTeam = findTeam(teamId);
        List<Card> cards = tempTeam.getCards();
        boolean find = false;
        for(int i = 0; i<cards.size(); i++){
            if(cards.get(i).getId()==cardId){
                int cardPoints = cards.get(i).getPoints();
                cards.remove(i);
                find = true;
                int currentCommonPoints = tempTeam.getCommonPoints();
                tempTeam.setCommonPoints(currentCommonPoints-cardPoints);
                updateTeam(tempTeam);
                System.out.println("Card deleted successfully.");
                break;
            }
        }
        if(!find){
            System.out.println("Team "+teamId+" has no card with id "+cardId);
        }
    }

    @Override
    @Transactional
    public void tranferCard(int fromTeamId, int toTeamId, int cardId) {
        Team tempTeam1 = findTeam(fromTeamId);
        Team tempTeam2 = findTeam(toTeamId);
        List<Card> cards1 = tempTeam1.getCards();
        List<Card> cards2 = tempTeam2.getCards();
        boolean find = false;
        for(int i = 0; i<cards1.size(); i++){
            if(cards1.get(i).getId()==cardId){
                Card tempCard = cards1.get(i);
                int currentCommonPoints1 = tempTeam1.getCommonPoints();
                tempTeam1.setCommonPoints(currentCommonPoints1-tempCard.getPoints());
                int currentCommonPoints2 = tempTeam2.getCommonPoints();
                tempTeam2.setCommonPoints(currentCommonPoints2+tempCard.getPoints());
                cards1.remove(i);
                cards2.add(tempCard);
                find = true;
                updateTeam(tempTeam2);
                updateTeam(tempTeam1);
                break;
            }
        }
        if(!find){
            System.out.println("No card found with id "+cardId);
        }
    }

    @Override
    @Transactional
    public void addMoney(int teamId, int money) {
        Team tempTeam = findTeam(teamId);
        int amount = tempTeam.getAmount();
        tempTeam.setAmount(amount+money);
        System.out.println("Embers added successfully.");
        System.out.println("Embers remaining in purse = "+ (amount+money));
        updateTeam(tempTeam);
    }

    @Override
    @Transactional
    public void removeMoney(int teamId, int money) {
        Team tempTeam = findTeam(teamId);
        int amount = tempTeam.getAmount();
        if(amount<money){
            System.out.println("Not enough Embers "+ amount);
        }else{
            tempTeam.setAmount(amount-money);
            System.out.println("Embers deducted successfully");
            System.out.println("Embers remaining = "+ (amount-money));
            updateTeam(tempTeam);
        }
    }

    @Override
    @Transactional
    public void tranferMoney(int fromId, int toid, int money) {
        Team tempTeam1 = findTeam(fromId);
        Team tempTeam2 = findTeam(toid);
        int amount1 = tempTeam1.getAmount();
        if(amount1<money){
            System.out.println("Not enough money with team "+fromId+" = "+tempTeam1.getAmount());
        }else{
            tempTeam1.setAmount(amount1-money);
            int amount2 = tempTeam2.getAmount();
            tempTeam2.setAmount(amount2+money);
            updateTeam(tempTeam1);
            updateTeam(tempTeam2);
            System.out.println("Embers transferred from team "+fromId+" to team "+toid);
        }
    }

    @Override
    @Transactional
    public void addAchievement(int teamId, int achievementId) {
        Achievement tempAchievement = findAchievement(achievementId);
        Team tempTeam = findTeam(teamId);
        tempTeam.addAchivement(tempAchievement);
        updateTeam(tempTeam);
        System.out.println("Card Added successfully to team "+teamId+". \n Amount remaining with team "+ teamId+ "= "+tempTeam.getAmount());
    }

    @Override
    @Transactional
    public void addAchievementPoints(int teamId, int points) {
        Team tempTeam = findTeam(teamId);
        int aPoint = tempTeam.getAchievementPoints();
        tempTeam.setAchievementPoints(aPoint+points);
        updateTeam(tempTeam);
        System.out.println(points+" Aurums added successfully to Team "+teamId+" , Total - "+tempTeam.getAchievementPoints());
    }

    @Override
    @Transactional
    public void removeAurums(int teamId, int choice) {
        Team tempTeam = findTeam(teamId);
        switch(choice){
            case 1:
                if(tempTeam.getAchievementPoints()<60 || getCardList(teamId).size()>=6){
                    System.out.println("Not enough Aurums or Maximum number of cards reached.");
                    System.out.println("Penalty of 2000 Embers imposed.");
                    removeMoney(teamId, 2000);
                    return;
                }
                removeAchievementPoints(teamId, 60);
                System.out.println("Enter the team ID from which you want to steal - ");
                int team2Id = sc.nextInt();
                Team tempTeam2 = findTeam(team2Id);
                List<Card> cardList = getCardList(team2Id);
                if(tempTeam2.getAchievementPoints()>=55){
                    System.out.println("Do Team "+team2Id+" want to use hide (55 Aurums) - Enter 1 for YES and 0 for NO");
                    int want = sc.nextInt();
                    if(want == 1){
                        removeAchievementPoints(team2Id, 55);
                        System.out.println("Hide Ability Applied!! Card saved.");
                        return;
                    }else{
                        int size = cardList.size();
                        Card temCard = cardList.get(size-1);
                        int id = temCard.getId();
                        tranferCard(team2Id, teamId, id);
                        System.out.println("Steal Successfull. Card "+id+" transfered from Team "+team2Id+" to Team "+teamId);
                    }
                }else{
                        int size = cardList.size();
                        Card temCard = cardList.get(size-1);
                        int id = temCard.getId();
                        tranferCard(team2Id, teamId, id);
                        System.out.println("Steal Successfull.");
                    }
            break;
            case 2:
                if(tempTeam.getAchievementPoints()<30){
                    System.out.println("Not enough Aurums.");
                    System.out.println("Penalty of 2000 Embers imposed.");
                    removeMoney(teamId, 2000);
                    return;
                }
                removeAchievementPoints(teamId, 30);
                System.out.println("Enter the team ID on which you want to use freeze - ");
                team2Id = sc.nextInt();
                tempTeam2 = findTeam(team2Id);
                System.out.println("Succefully Freezed Team "+team2Id+" by Team "+teamId);
            break;
            case 3:
                if(tempTeam.getAchievementPoints()<25){
                    System.out.println("Not enough Aurums.");
                    System.out.println("Penalty of 2000 Embers imposed.");
                    removeMoney(teamId, 2000);
                    return;
                }
                removeAchievementPoints(teamId, 25);
                cardList = getCardList(teamId);
                int size = cardList.size();
                Card temCard = cardList.get(size-1);
                int sp = temCard.getSellingPrice();
                int discount = (int)(0.15*sp);
                temCard.setSellingPrice(sp-discount);
                addMoney(teamId, discount);
                updateCard(temCard);
                System.out.println("Discount applied Successfully.");
            break;
            case 4:
                if(tempTeam.getAchievementPoints()<50 && tempTeam.getCards().size()==0){
                    System.out.println("Not enough Aurums or No cards available.");
                    System.out.println("Penalty of 2000 Embers imposed.");
                    removeMoney(teamId, 2000);
                    return;
                }
                removeAchievementPoints(teamId, 50);
                System.out.println("Enter the card id which the team wish to upgrade - ");
                int cardId = sc.nextInt();
                Card tempCard = findCard(cardId);
                if(!tempTeam.getCards().contains(tempCard)){
                    System.out.println("The team does not have the card with ID "+cardId);
                    System.out.println("Penalty of 2000 Embers imposed.");
                    removeMoney(teamId, 2000);
                    return;
                }
                tempCard.setPoints(tempCard.getPoints()+7);
                findTeam(teamId).setCommonPoints(findTeam(teamId).getCommonPoints()+7);
                updateCard(tempCard);
                updateTeam(findTeam(teamId));
                System.out.println("Card with id "+tempCard.getId()+" upgraded successfully.");
            break;
            case 5:
                if(tempTeam.getAchievementPoints()<40){
                    System.out.println("Not enough Aurums");
                    System.out.println("Penalty of 2000 Embers imposed.");
                    removeMoney(teamId, 2000);
                    return;
                }
                removeAchievementPoints(teamId, 40);
                addMoney(teamId, 5000);
                System.out.println("5000 Embers added to the purse successfully - "+tempTeam.getAmount());
            break;
            case 6:
                if(tempTeam.getAchievementPoints()<35){
                    System.out.println("Not enough Aurums");
                    System.out.println("Penalty of 2000 Embers imposed.");
                    removeMoney(teamId, 2000);
                    return;
                }
                removeAchievementPoints(teamId, 35);
                System.out.println("Freeze removed successfully.");
            break;
            case 7:
                if(tempTeam.getAchievementPoints()<25){
                    System.out.println("Not enough Aurums");
                    System.out.println("Penalty of 2000 Embers imposed.");
                    removeMoney(teamId, 2000);
                    return;
                }
                removeAchievementPoints(teamId, 25);
                System.out.println("Enter the team id which you want to Bankrupt - ");
                team2Id = sc.nextInt();
                if(findTeam(team2Id).getAmount()<3000){
                    System.out.println("The opposing Team does not have Enough money to be sloten.");
                    return;
                }
                tranferMoney(team2Id, teamId, 3000);
                System.out.println("Team "+team2Id+" bankrupted successfully.");
            break;
        }
    }

    @Override
    @Transactional
    public void removeAchievementPoints(int teamId, int points) {
        Team tempTeam = findTeam(teamId);
        int aPoint = tempTeam.getAchievementPoints();
        if(aPoint<points){
            System.out.println("Not enough achievement points");
        }else{
            tempTeam.setAchievementPoints(aPoint-points);
            updateTeam(tempTeam);
            System.out.println((points)+" Aurums removed successfuly from Team "+teamId);
        }
    }

    public List<Card> getCardList(int teamId){
        Team tempTeam = findTeam(teamId);
        List<Card> cards = tempTeam.getCards();
        return cards;
    }

    @Override
    @Transactional
    public void updateRanks() {
        List<Team> teams = getTeams();
        for(int i = 0; i<teams.size(); i++){
            int starDust = teams.get(i).getCommonPoints();
            int money = teams.get(i).getAmount();
            int extra = money/3000;
            teams.get(i).setCommonPoints(starDust+extra);
            updateTeam(teams.get(i));
        }
        TypedQuery<Team> theQuery = entityManager.createQuery("From Team ORDER BY commonPoints desc", Team.class);
        //execute the query
        teams = theQuery.getResultList();
        for(int i = 0; i<teams.size(); i++){
            teams.get(i).setRank(i+1);
            updateTeam(teams.get(i));
            System.out.println(teams.get(i).toString());
        }
    }
    @Override
    public List<Team> getTeams() {
        TypedQuery<Team> theQuery = entityManager.createQuery("From Team", Team.class);
        //execute the query
        List<Team> teams = theQuery.getResultList();
        return teams;
    }
}
