package com.Techno23.CoinQuest.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "card")
public class Card {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "points")
    private int points;

    @Column(name = "category")
    private int category;

    @Column(name = "card_name")
    private String name;

    @Column(name = "base_price")
    private int basePrice;

    @Column(name = "selling_price")
    private int sellingPrice;
    
    public Card(int points, int category, String name,int basePrice) {
        this.points = points;
        this.category = category;
        this.name = name;
        this.basePrice = basePrice;
    }
    
    public Card() {
    }

    public int getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(int basePrice) {
        this.basePrice = basePrice;
    }

    public int getSellingPrice() {
        return sellingPrice;
    }

    public void setSellingPrice(int sellingPrice) {
        this.sellingPrice = sellingPrice;
    }

    public int getCategory() {
        return category;
    }

    @Override
    public String toString() {
        return "ID=" + id + ", name=" + name + ", points=" + points + ", category=" + category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }
}
